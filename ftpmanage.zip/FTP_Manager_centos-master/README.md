# FTP_Manager
This is a linux shell script which is used to install and manage ftp.Any suggestions and updates are welcome.please give me your  feedback on this after using the script.
